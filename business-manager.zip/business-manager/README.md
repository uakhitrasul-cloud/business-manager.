# Business Manager

A single-page, all-in-one business management dashboard for small business owners and freelancers — track revenue and expenses, generate reports, take notes, manage tasks, and keep a lightweight CRM, all in one place. No backend, no build step: everything runs in the browser and persists to `localStorage`.

## Features

- **Dashboard** — total revenue, expenses, net profit, customer and task counts, a business performance chart, plus recent transactions and notes at a glance.
- **Finance** — add/edit/delete income and expenses, categorize, search, filter by type/category, and see totals and a category breakdown chart.
- **Reports** — generate revenue/expense/profit reports for any date range (or quick presets: this month, last month, last 30 days, this year), see the best-performing category, and browse report history.
- **Notes** — create/edit/delete notes with categories and tags, pin important ones, and search across titles, content, and tags.
- **Tasks** — create/edit/delete tasks with deadline, priority, category and status; filter by To Do / In Progress / Completed; mark complete in one click.
- **Customers (mini-CRM)** — add/edit/delete customers with company, contact, status and notes; search and filter by status.
- Responsive layout for desktop, tablet, and mobile, with a collapsible sidebar on small screens.

## Tech stack

- HTML5, CSS3, Vanilla JavaScript (no frameworks)
- `localStorage` for data persistence — everything stays on your device
- [Chart.js](https://www.chartjs.org/) (via CDN) for charts
- Hash-based client-side routing (`#dashboard`, `#finance`, ...) — no page reloads

## Project structure

```
business-manager/
├── README.md
├── index.html                  # App shell: loads all styles/scripts, mounts sidebar/navbar/content
│
├── src/
│   ├── app.js                  # Router + app bootstrap + Notifications (toast) module
│   │
│   ├── pages/                  # One folder per section: markup fragment + controller
│   │   ├── dashboard/{dashboard.html, dashboard.js}
│   │   ├── finance/{finance.html, finance.js}
│   │   ├── reports/{reports.html, reports.js}
│   │   ├── notes/{notes.html, notes.js}
│   │   ├── tasks/{tasks.html, tasks.js}
│   │   └── customers/{customers.html, customers.js}
│   │
│   ├── components/             # Reusable UI building blocks
│   │   ├── sidebar/sidebar.js
│   │   ├── navbar/navbar.js
│   │   ├── modal/modal.js
│   │   ├── cards/cards.js
│   │   ├── tables/tables.js
│   │   └── charts/charts.js
│   │
│   ├── services/                # Data access + business logic (the only code that touches storage)
│   │   ├── storage.js           # Single localStorage access layer (get/insert/update/remove)
│   │   ├── financeService.js
│   │   ├── notesService.js
│   │   ├── taskService.js
│   │   ├── customerService.js
│   │   └── reportService.js
│   │
│   └── utils/
│       ├── formatters.js        # currency/date/number formatting
│       ├── calculations.js      # sums, profit, grouping, date-range filtering
│       └── validators.js        # form validation helpers
│
├── styles/
│   ├── main.css                 # variables, layout, sidebar/navbar, responsive rules
│   ├── components.css           # cards, tables, modal, buttons, forms, badges, toasts
│   ├── dashboard.css / finance.css / reports.css / notes.css / tasks.css
│
├── assets/{icons,images}/       # place custom icons/images here
└── docs/screenshots/            # place app screenshots here
```

### Architecture at a glance

- `services/` are the **only** files that read/write `localStorage`, always through `storage.js`. This keeps data access in one place and makes it trivial to swap `localStorage` for a real API later.
- `pages/` contain UI + event wiring for one section each. A page module exposes `render(container)` and calls into its service for data.
- `components/` are stateless render helpers reused across pages (stat cards, tables, the modal, charts).
- `utils/` are pure functions with no DOM or storage access.
- `app.js` wires it all together: it listens to `hashchange`, mounts the sidebar/navbar, and renders the active page into `#pageContent` — no full page reloads.

## Running locally

Because pages are loaded via `fetch()` (`src/pages/.../*.html`), browsers block this under the `file://` protocol. Serve the folder with any static server:

```bash
# Option 1 — Python
cd business-manager
python3 -m http.server 8080

# Option 2 — Node
npx serve business-manager

# Option 3 — VS Code
# Right-click index.html → "Open with Live Server"
```

Then open `http://localhost:8080` in your browser. All data is stored locally in your browser's `localStorage` — clearing your browser storage will reset the app.

## Publishing to GitHub

```bash
cd business-manager
git init
git add .
git commit -m "Initial commit: Business Manager v1.0.0"
git branch -M main
git remote add origin https://github.com/<your-username>/business-manager.git
git push -u origin main
```

## Roadmap / future versions

- Export/import data (JSON/CSV) and PDF export for reports
- Multi-currency support
- User accounts and cloud sync (replacing `localStorage` with a real backend)
- Recurring transactions and budgets with alerts
- Task reminders / due-date notifications
- Drag-and-drop Kanban view for Tasks
- Dark mode
- Role-based access for team members
