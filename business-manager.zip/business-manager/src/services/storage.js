/**
 * storage.js
 * Единый слой работы с LocalStorage.
 * Все сервисы (finance, notes, tasks, customers) работают ТОЛЬКО через этот модуль.
 */

const Storage = (() => {
  const PREFIX = 'bm_'; // business-manager namespace

  function _key(collection) {
    return `${PREFIX}${collection}`;
  }

  /** Возвращает весь массив записей коллекции */
  function getAll(collection) {
    try {
      const raw = localStorage.getItem(_key(collection));
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error(`Storage.getAll error for "${collection}":`, e);
      return [];
    }
  }

  /** Полностью перезаписывает коллекцию */
  function saveAll(collection, items) {
    try {
      localStorage.setItem(_key(collection), JSON.stringify(items));
      return true;
    } catch (e) {
      console.error(`Storage.saveAll error for "${collection}":`, e);
      return false;
    }
  }

  /** Добавляет запись, генерируя id и createdAt */
  function insert(collection, item) {
    const items = getAll(collection);
    const record = {
      id: item.id || _generateId(),
      createdAt: item.createdAt || new Date().toISOString(),
      ...item,
    };
    record.id = record.id || _generateId();
    items.push(record);
    saveAll(collection, items);
    return record;
  }

  /** Обновляет запись по id, сливая новые поля */
  function update(collection, id, patch) {
    const items = getAll(collection);
    const idx = items.findIndex((i) => i.id === id);
    if (idx === -1) return null;
    items[idx] = { ...items[idx], ...patch, updatedAt: new Date().toISOString() };
    saveAll(collection, items);
    return items[idx];
  }

  /** Удаляет запись по id */
  function remove(collection, id) {
    const items = getAll(collection);
    const filtered = items.filter((i) => i.id !== id);
    saveAll(collection, filtered);
    return filtered.length !== items.length;
  }

  /** Находит одну запись по id */
  function getById(collection, id) {
    return getAll(collection).find((i) => i.id === id) || null;
  }

  /** Очищает коллекцию (используется в настройках/сбросе) */
  function clear(collection) {
    localStorage.removeItem(_key(collection));
  }

  function _generateId() {
    return `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
  }

  /** Гарантирует, что коллекция инициализирована демо-структурой (пустым массивом) */
  function ensure(collection) {
    if (localStorage.getItem(_key(collection)) === null) {
      saveAll(collection, []);
    }
  }

  return { getAll, saveAll, insert, update, remove, getById, clear, ensure };
})();
