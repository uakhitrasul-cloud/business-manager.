/**
 * customerService.js — простой CRM-слой
 * Коллекция: "customers". Запись: { id, name, contact, company, notes, status, createdAt }
 * status: 'lead' | 'active' | 'inactive'
 */

const CustomerService = (() => {
  const COLLECTION = 'customers';
  Storage.ensure(COLLECTION);

  function getAll() {
    return Storage.getAll(COLLECTION).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  function add(data) {
    return Storage.insert(COLLECTION, {
      name: data.name,
      contact: data.contact || '',
      company: data.company || '',
      notes: data.notes || '',
      status: data.status || 'lead',
    });
  }

  function edit(id, data) {
    return Storage.update(COLLECTION, id, {
      name: data.name,
      contact: data.contact,
      company: data.company,
      notes: data.notes,
      status: data.status,
    });
  }

  function remove(id) {
    return Storage.remove(COLLECTION, id);
  }

  function search(query) {
    const q = (query || '').toLowerCase().trim();
    if (!q) return getAll();
    return getAll().filter(
      (c) =>
        c.name.toLowerCase().includes(q) ||
        c.company.toLowerCase().includes(q) ||
        c.contact.toLowerCase().includes(q)
    );
  }

  function filterByStatus(status) {
    if (!status || status === 'all') return getAll();
    return getAll().filter((c) => c.status === status);
  }

  function count() {
    return getAll().length;
  }

  return { getAll, add, edit, remove, search, filterByStatus, count, COLLECTION };
})();
