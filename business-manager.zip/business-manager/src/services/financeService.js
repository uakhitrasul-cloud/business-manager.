/**
 * financeService.js — бизнес-логика доходов/расходов поверх Storage
 * Коллекция: "transactions". Запись: { id, type: 'income'|'expense', amount, category, date, description }
 */

const FinanceService = (() => {
  const COLLECTION = 'transactions';
  Storage.ensure(COLLECTION);

  function getAll() {
    return Storage.getAll(COLLECTION).sort((a, b) => new Date(b.date) - new Date(a.date));
  }

  function add(data) {
    return Storage.insert(COLLECTION, {
      type: data.type,
      amount: Number(data.amount),
      category: data.category || 'Other',
      date: data.date || new Date().toISOString().slice(0, 10),
      description: data.description || '',
    });
  }

  function edit(id, data) {
    return Storage.update(COLLECTION, id, {
      type: data.type,
      amount: Number(data.amount),
      category: data.category,
      date: data.date,
      description: data.description,
    });
  }

  function remove(id) {
    return Storage.remove(COLLECTION, id);
  }

  function search(query) {
    const q = (query || '').toLowerCase().trim();
    if (!q) return getAll();
    return getAll().filter(
      (t) =>
        t.description.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        String(t.amount).includes(q)
    );
  }

  function filter({ type, category, start, end } = {}) {
    let items = getAll();
    if (type && type !== 'all') items = items.filter((t) => t.type === type);
    if (category && category !== 'all') items = items.filter((t) => t.category === category);
    if (start || end) items = Calculations.filterByDateRange(items, start, end);
    return items;
  }

  function categories() {
    const set = new Set(getAll().map((t) => t.category));
    return Array.from(set);
  }

  function summary() {
    const all = getAll();
    const income = Calculations.totalByType(all, 'income');
    const expense = Calculations.totalByType(all, 'expense');
    return {
      income,
      expense,
      profit: income - expense,
      balance: income - expense,
      count: all.length,
    };
  }

  function recent(limit = 5) {
    return getAll().slice(0, limit);
  }

  return { getAll, add, edit, remove, search, filter, categories, summary, recent, COLLECTION };
})();
