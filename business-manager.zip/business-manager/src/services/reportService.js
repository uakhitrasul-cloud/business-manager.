/**
 * reportService.js — генерация бизнес-отчётов за период на основе FinanceService
 * Отчёты не хранятся отдельно — они всегда строятся "на лету" из транзакций,
 * но история сгенерированных отчётов сохраняется в коллекции "reports" для истории.
 */

const ReportService = (() => {
  const COLLECTION = 'reports';
  Storage.ensure(COLLECTION);

  function generate({ start, end, label } = {}) {
    const transactions = Calculations.filterByDateRange(FinanceService.getAll(), start, end);
    const income = Calculations.totalByType(transactions, 'income');
    const expense = Calculations.totalByType(transactions, 'expense');
    const profit = income - expense;

    const report = {
      label: label || `Report ${Formatters.date(start)} — ${Formatters.date(end)}`,
      start,
      end,
      revenue: income,
      expenses: expense,
      profit,
      transactionCount: transactions.length,
      bestCategory: Calculations.bestCategory(transactions, 'income') || '—',
      byCategory: Calculations.groupByCategory(transactions),
      byMonth: Calculations.groupByMonth(transactions),
    };

    Storage.insert(COLLECTION, report);
    return report;
  }

  function history() {
    return Storage.getAll(COLLECTION).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  function remove(id) {
    return Storage.remove(COLLECTION, id);
  }

  /** Готовые быстрые периоды */
  function presetRange(preset) {
    const now = new Date();
    let start;
    let end = now.toISOString().slice(0, 10);

    if (preset === 'this_month') {
      start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
    } else if (preset === 'last_month') {
      const first = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const last = new Date(now.getFullYear(), now.getMonth(), 0);
      start = first.toISOString().slice(0, 10);
      end = last.toISOString().slice(0, 10);
    } else if (preset === 'this_year') {
      start = new Date(now.getFullYear(), 0, 1).toISOString().slice(0, 10);
    } else if (preset === 'last_30_days') {
      const d = new Date();
      d.setDate(d.getDate() - 30);
      start = d.toISOString().slice(0, 10);
    } else {
      start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
    }
    return { start, end };
  }

  return { generate, history, remove, presetRange, COLLECTION };
})();
