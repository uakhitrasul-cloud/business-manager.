/**
 * notesService.js — заметки бизнеса
 * Коллекция: "notes". Запись: { id, title, content, category, tags[], pinned, createdAt, updatedAt }
 */

const NotesService = (() => {
  const COLLECTION = 'notes';
  Storage.ensure(COLLECTION);

  function getAll() {
    return Storage.getAll(COLLECTION).sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt);
    });
  }

  function add(data) {
    return Storage.insert(COLLECTION, {
      title: data.title,
      content: data.content || '',
      category: data.category || 'General',
      tags: data.tags || [],
      pinned: !!data.pinned,
    });
  }

  function edit(id, data) {
    return Storage.update(COLLECTION, id, {
      title: data.title,
      content: data.content,
      category: data.category,
      tags: data.tags,
    });
  }

  function remove(id) {
    return Storage.remove(COLLECTION, id);
  }

  function togglePin(id) {
    const note = Storage.getById(COLLECTION, id);
    if (!note) return null;
    return Storage.update(COLLECTION, id, { pinned: !note.pinned });
  }

  function search(query) {
    const q = (query || '').toLowerCase().trim();
    if (!q) return getAll();
    return getAll().filter(
      (n) =>
        n.title.toLowerCase().includes(q) ||
        n.content.toLowerCase().includes(q) ||
        (n.tags || []).some((t) => t.toLowerCase().includes(q))
    );
  }

  function filterByCategory(category) {
    if (!category || category === 'all') return getAll();
    return getAll().filter((n) => n.category === category);
  }

  function categories() {
    return Array.from(new Set(getAll().map((n) => n.category)));
  }

  function recent(limit = 5) {
    return getAll().slice(0, limit);
  }

  return { getAll, add, edit, remove, togglePin, search, filterByCategory, categories, recent, COLLECTION };
})();
