/**
 * taskService.js — управление задачами
 * Коллекция: "tasks". Запись: { id, title, description, deadline, priority, status, category }
 * status: 'todo' | 'in_progress' | 'completed'
 */

const TaskService = (() => {
  const COLLECTION = 'tasks';
  Storage.ensure(COLLECTION);

  function getAll() {
    return Storage.getAll(COLLECTION).sort((a, b) => new Date(a.deadline || 0) - new Date(b.deadline || 0));
  }

  function add(data) {
    return Storage.insert(COLLECTION, {
      title: data.title,
      description: data.description || '',
      deadline: data.deadline || '',
      priority: data.priority || 'medium',
      status: data.status || 'todo',
      category: data.category || 'General',
    });
  }

  function edit(id, data) {
    return Storage.update(COLLECTION, id, {
      title: data.title,
      description: data.description,
      deadline: data.deadline,
      priority: data.priority,
      status: data.status,
      category: data.category,
    });
  }

  function remove(id) {
    return Storage.remove(COLLECTION, id);
  }

  function setStatus(id, status) {
    return Storage.update(COLLECTION, id, { status });
  }

  function complete(id) {
    return setStatus(id, 'completed');
  }

  function filterByStatus(status) {
    if (!status || status === 'all') return getAll();
    return getAll().filter((t) => t.status === status);
  }

  function search(query) {
    const q = (query || '').toLowerCase().trim();
    if (!q) return getAll();
    return getAll().filter(
      (t) => t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q) || t.category.toLowerCase().includes(q)
    );
  }

  function counts() {
    const all = getAll();
    return {
      total: all.length,
      todo: all.filter((t) => t.status === 'todo').length,
      in_progress: all.filter((t) => t.status === 'in_progress').length,
      completed: all.filter((t) => t.status === 'completed').length,
    };
  }

  return { getAll, add, edit, remove, setStatus, complete, filterByStatus, search, counts, COLLECTION };
})();
