/**
 * navbar.js — верхняя панель: заголовок страницы + переключатель мобильного меню
 */

const Navbar = (() => {
  const TITLES = {
    dashboard: 'Dashboard',
    finance: 'Finance',
    reports: 'Reports',
    notes: 'Notes',
    tasks: 'Tasks',
    customers: 'Customers',
  };

  function render(route) {
    return `
      <button class="navbar-menu-btn" id="menuToggleBtn" aria-label="Toggle menu">☰</button>
      <h1 class="navbar-title">${TITLES[route] || 'Business Manager'}</h1>
      <div class="navbar-actions">
        <span class="navbar-date">${Formatters.date(new Date().toISOString())}</span>
      </div>
    `;
  }

  function mount(container, route) {
    container.innerHTML = render(route);
    const btn = container.querySelector('#menuToggleBtn');
    if (btn) {
      btn.addEventListener('click', () => {
        document.querySelector('.sidebar').classList.toggle('open');
      });
    }
  }

  return { render, mount, TITLES };
})();
