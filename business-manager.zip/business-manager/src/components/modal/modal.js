/**
 * modal.js — переиспользуемое модальное окно
 * Использование: Modal.open({ title, bodyHtml, onSubmit, submitLabel })
 */

const Modal = (() => {
  let root = null;

  function ensureRoot() {
    if (!root) {
      root = document.getElementById('modalRoot');
    }
    return root;
  }

  function open({ title, bodyHtml, submitLabel = 'Save', onSubmit, hideFooter = false }) {
    const el = ensureRoot();
    el.innerHTML = `
      <div class="modal-overlay" id="modalOverlay">
        <div class="modal-box">
          <div class="modal-header">
            <h2>${title}</h2>
            <button class="modal-close" id="modalCloseBtn" aria-label="Close">✕</button>
          </div>
          <form class="modal-body" id="modalForm">${bodyHtml}</form>
          ${
            hideFooter
              ? ''
              : `<div class="modal-footer">
                  <button type="button" class="btn btn-secondary" id="modalCancelBtn">Cancel</button>
                  <button type="submit" form="modalForm" class="btn btn-primary">${submitLabel}</button>
                </div>`
          }
        </div>
      </div>
    `;
    el.classList.add('active');

    const close = () => Modal.close();
    document.getElementById('modalCloseBtn').addEventListener('click', close);
    if (!hideFooter) document.getElementById('modalCancelBtn').addEventListener('click', close);
    document.getElementById('modalOverlay').addEventListener('click', (e) => {
      if (e.target.id === 'modalOverlay') close();
    });

    const form = document.getElementById('modalForm');
    if (onSubmit) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        onSubmit(data, close);
      });
    }
  }

  function close() {
    const el = ensureRoot();
    el.classList.remove('active');
    el.innerHTML = '';
  }

  return { open, close };
})();
