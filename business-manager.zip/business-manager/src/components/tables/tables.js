/**
 * tables.js — генератор HTML-таблиц с action-кнопками (edit/delete)
 */

const Tables = (() => {
  /**
   * columns: [{ key, label, render?: (row) => string }]
   * rows: array of data objects (must contain `id`)
   * actions: array of { label, className, event } — event используется как data-action атрибут
   */
  function render({ columns, rows, actions = [], emptyMessage = 'No records found' }) {
    if (!rows.length) {
      return `<div class="table-empty">${emptyMessage}</div>`;
    }

    const head = columns.map((c) => `<th>${c.label}</th>`).join('') + (actions.length ? '<th class="col-actions">Actions</th>' : '');

    const body = rows
      .map((row) => {
        const cells = columns
          .map((c) => `<td data-label="${c.label}">${c.render ? c.render(row) : row[c.key] ?? ''}</td>`)
          .join('');
        const actionCells = actions.length
          ? `<td class="col-actions">${actions
              .map(
                (a) =>
                  `<button class="table-action-btn ${a.className || ''}" data-action="${a.event}" data-id="${row.id}">${a.label}</button>`
              )
              .join('')}</td>`
          : '';
        return `<tr data-id="${row.id}">${cells}${actionCells}</tr>`;
      })
      .join('');

    return `
      <div class="table-wrapper">
        <table class="data-table">
          <thead><tr>${head}</tr></thead>
          <tbody>${body}</tbody>
        </table>
      </div>
    `;
  }

  return { render };
})();
