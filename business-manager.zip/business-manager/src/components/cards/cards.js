/**
 * cards.js — карточки метрик (KPI) для Dashboard / Reports
 */

const Cards = (() => {
  function stat({ label, value, icon = '', trend = null, accent = 'default' }) {
    const trendHtml =
      trend === null
        ? ''
        : `<span class="stat-trend ${trend >= 0 ? 'up' : 'down'}">${trend >= 0 ? '▲' : '▼'} ${Math.abs(trend).toFixed(1)}%</span>`;
    return `
      <div class="stat-card accent-${accent}">
        <div class="stat-card-top">
          <span class="stat-icon">${icon}</span>
          ${trendHtml}
        </div>
        <div class="stat-value">${value}</div>
        <div class="stat-label">${label}</div>
      </div>
    `;
  }

  function renderGrid(items) {
    return `<div class="stats-grid">${items.map(stat).join('')}</div>`;
  }

  function simpleCard({ title, bodyHtml, footerHtml = '' }) {
    return `
      <div class="panel-card">
        <div class="panel-card-header"><h3>${title}</h3></div>
        <div class="panel-card-body">${bodyHtml}</div>
        ${footerHtml ? `<div class="panel-card-footer">${footerHtml}</div>` : ''}
      </div>
    `;
  }

  return { stat, renderGrid, simpleCard };
})();
