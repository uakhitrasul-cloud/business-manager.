/**
 * sidebar.js — боковая навигация приложения
 */

const Sidebar = (() => {
  const ITEMS = [
    { route: 'dashboard', label: 'Dashboard', icon: '📊' },
    { route: 'finance', label: 'Finance', icon: '💰' },
    { route: 'reports', label: 'Reports', icon: '📈' },
    { route: 'notes', label: 'Notes', icon: '📝' },
    { route: 'tasks', label: 'Tasks', icon: '✅' },
    { route: 'customers', label: 'Customers', icon: '👥' },
  ];

  function render(activeRoute) {
    return `
      <div class="sidebar-brand">
        <span class="sidebar-brand-icon">🧭</span>
        <span class="sidebar-brand-text">Business Manager</span>
      </div>
      <nav class="sidebar-nav">
        ${ITEMS.map(
          (item) => `
          <a href="#${item.route}" class="sidebar-link ${activeRoute === item.route ? 'active' : ''}" data-route="${item.route}">
            <span class="sidebar-icon">${item.icon}</span>
            <span class="sidebar-label">${item.label}</span>
          </a>`
        ).join('')}
      </nav>
      <div class="sidebar-footer">
        <span>v1.0.0 · Local data</span>
      </div>
    `;
  }

  function mount(container, activeRoute) {
    container.innerHTML = render(activeRoute);
  }

  function setActive(route) {
    document.querySelectorAll('.sidebar-link').forEach((el) => {
      el.classList.toggle('active', el.dataset.route === route);
    });
  }

  return { render, mount, setActive, ITEMS };
})();
