/**
 * app.js — точка входа приложения: роутинг между страницами (SPA без перезагрузки)
 * и общая инициализация.
 */

/** Небольшой модуль уведомлений (toast), используется всеми страницами */
const Notifications = (() => {
  function show(message, type = 'info') {
    const container = document.getElementById('notificationsRoot');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('show'));
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 250);
    }, 2800);
  }
  return { show };
})();

const App = (() => {
  const PAGES = {
    dashboard: DashboardPage,
    finance: FinancePage,
    reports: ReportsPage,
    notes: NotesPage,
    tasks: TasksPage,
    customers: CustomersPage,
  };

  let currentRoute = null;

  function getRouteFromHash() {
    const hash = window.location.hash.replace('#', '');
    return PAGES[hash] ? hash : 'dashboard';
  }

  async function navigate(route) {
    if (!PAGES[route]) route = 'dashboard';
    currentRoute = route;

    const contentEl = document.getElementById('pageContent');
    contentEl.classList.add('loading');

    Sidebar.setActive(route);
    Navbar.mount(document.getElementById('navbar'), route);

    try {
      await PAGES[route].render(contentEl);
    } catch (err) {
      console.error('Failed to render page', route, err);
      contentEl.innerHTML = `<div class="table-empty">Failed to load this page. If you opened index.html directly (file://), please serve the project with a local server (see README).</div>`;
    }

    contentEl.classList.remove('loading');
    document.querySelector('.sidebar').classList.remove('open');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function bindSidebarClicks() {
    document.getElementById('sidebar').addEventListener('click', (e) => {
      const link = e.target.closest('.sidebar-link');
      if (!link) return;
      e.preventDefault();
      const route = link.dataset.route;
      if (route !== currentRoute) {
        window.location.hash = route;
      }
    });
  }

  function init() {
    Sidebar.mount(document.getElementById('sidebar'), getRouteFromHash());
    bindSidebarClicks();

    window.addEventListener('hashchange', () => navigate(getRouteFromHash()));

    navigate(getRouteFromHash());
  }

  return { init, navigate };
})();

document.addEventListener('DOMContentLoaded', App.init);
