/**
 * validators.js — валидация форм перед сохранением в Storage
 */

const Validators = (() => {
  function required(value) {
    return value !== undefined && value !== null && String(value).trim().length > 0;
  }

  function isNumber(value) {
    return value !== '' && !isNaN(Number(value));
  }

  function isPositive(value) {
    return isNumber(value) && Number(value) > 0;
  }

  function isEmail(value) {
    if (!value) return true; // email часто необязателен
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
  }

  function isDate(value) {
    return !isNaN(new Date(value).getTime());
  }

  /**
   * Валидирует объект по схеме { field: [validatorFn, message] }
   * Возвращает { valid: bool, errors: { field: message } }
   */
  function validate(data, schema) {
    const errors = {};
    Object.entries(schema).forEach(([field, rules]) => {
      for (const [fn, message] of rules) {
        if (!fn(data[field])) {
          errors[field] = message;
          break;
        }
      }
    });
    return { valid: Object.keys(errors).length === 0, errors };
  }

  return { required, isNumber, isPositive, isEmail, isDate, validate };
})();
