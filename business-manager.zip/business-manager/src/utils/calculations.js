/**
 * calculations.js — общая бизнес-математика (суммы, профит, агрегации по категориям)
 */

const Calculations = (() => {
  function sum(entries, field = 'amount') {
    return entries.reduce((acc, e) => acc + (Number(e[field]) || 0), 0);
  }

  function totalByType(transactions, type) {
    return sum(transactions.filter((t) => t.type === type));
  }

  function netProfit(transactions) {
    return totalByType(transactions, 'income') - totalByType(transactions, 'expense');
  }

  function groupByCategory(transactions) {
    const map = {};
    transactions.forEach((t) => {
      const cat = t.category || 'Uncategorized';
      map[cat] = (map[cat] || 0) + (Number(t.amount) || 0);
    });
    return map;
  }

  function bestCategory(transactions, type = 'income') {
    const grouped = groupByCategory(transactions.filter((t) => t.type === type));
    let best = null;
    let bestVal = -Infinity;
    Object.entries(grouped).forEach(([cat, val]) => {
      if (val > bestVal) {
        best = cat;
        bestVal = val;
      }
    });
    return best;
  }

  function groupByMonth(transactions) {
    const map = {};
    transactions.forEach((t) => {
      const d = new Date(t.date);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      if (!map[key]) map[key] = { income: 0, expense: 0 };
      map[key][t.type] += Number(t.amount) || 0;
    });
    return map;
  }

  function filterByDateRange(entries, start, end, field = 'date') {
    return entries.filter((e) => {
      const d = new Date(e[field]);
      if (start && d < new Date(start)) return false;
      if (end && d > new Date(end)) return false;
      return true;
    });
  }

  function percentChange(current, previous) {
    if (!previous) return current > 0 ? 100 : 0;
    return ((current - previous) / Math.abs(previous)) * 100;
  }

  return { sum, totalByType, netProfit, groupByCategory, bestCategory, groupByMonth, filterByDateRange, percentChange };
})();
