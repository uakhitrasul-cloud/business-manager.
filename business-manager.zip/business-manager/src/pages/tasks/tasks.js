/**
 * tasks.js — контроллер раздела Tasks
 */

const TasksPage = (() => {
  let state = { search: '', status: 'all' };

  async function render(container) {
    const html = await fetch('src/pages/tasks/tasks.html').then((r) => r.text());
    container.innerHTML = html;
    state = { search: '', status: 'all' };
    bindEvents();
    refresh();
  }

  function bindEvents() {
    document.getElementById('addTaskBtn').addEventListener('click', () => openForm());
    document.getElementById('taskSearch').addEventListener('input', (e) => {
      state.search = e.target.value;
      renderTable();
    });
    document.querySelectorAll('#taskStatusTabs .filter-tab').forEach((tab) =>
      tab.addEventListener('click', () => {
        state.status = tab.dataset.status;
        document.querySelectorAll('#taskStatusTabs .filter-tab').forEach((t) => t.classList.remove('active'));
        tab.classList.add('active');
        renderTable();
      })
    );
  }

  function refresh() {
    renderStats();
    renderTable();
  }

  function renderStats() {
    const c = TaskService.counts();
    document.getElementById('taskStats').innerHTML = Cards.renderGrid([
      { label: 'Total Tasks', value: Formatters.number(c.total), icon: '📋', accent: 'blue' },
      { label: 'To Do', value: Formatters.number(c.todo), icon: '🕓', accent: 'default' },
      { label: 'In Progress', value: Formatters.number(c.in_progress), icon: '🚧', accent: 'purple' },
      { label: 'Completed', value: Formatters.number(c.completed), icon: '✅', accent: 'green' },
    ]);
  }

  function getFilteredRows() {
    let rows = TaskService.filterByStatus(state.status);
    if (state.search) {
      const q = state.search.toLowerCase();
      rows = rows.filter((t) => t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q));
    }
    return rows;
  }

  const STATUS_LABELS = { todo: 'To Do', in_progress: 'In Progress', completed: 'Completed' };
  const PRIORITY_LABELS = { low: 'Low', medium: 'Medium', high: 'High' };

  function renderTable() {
    const rows = getFilteredRows();
    const html = Tables.render({
      columns: [
        { key: 'title', label: 'Title', render: (r) => `<strong>${r.title}</strong>` },
        { key: 'category', label: 'Category' },
        { key: 'deadline', label: 'Deadline', render: (r) => (r.deadline ? Formatters.date(r.deadline) : '—') },
        { key: 'priority', label: 'Priority', render: (r) => `<span class="badge badge-priority-${r.priority}">${PRIORITY_LABELS[r.priority] || r.priority}</span>` },
        {
          key: 'status',
          label: 'Status',
          render: (r) => `<span class="badge badge-status-${r.status}">${STATUS_LABELS[r.status] || r.status}</span>`,
        },
      ],
      rows,
      actions: [
        { label: 'Complete', event: 'complete', className: 'btn-ghost' },
        { label: 'Edit', event: 'edit', className: 'btn-ghost' },
        { label: 'Delete', event: 'delete', className: 'btn-danger-ghost' },
      ],
      emptyMessage: 'No tasks match your filters',
    });
    const wrapper = document.getElementById('taskTableWrapper');
    wrapper.innerHTML = html;

    wrapper.querySelectorAll('[data-action="complete"]').forEach((btn) =>
      btn.addEventListener('click', () => {
        TaskService.complete(btn.dataset.id);
        refresh();
        Notifications.show('Task marked as completed', 'success');
      })
    );
    wrapper.querySelectorAll('[data-action="edit"]').forEach((btn) =>
      btn.addEventListener('click', () => openForm(Storage.getById(TaskService.COLLECTION, btn.dataset.id)))
    );
    wrapper.querySelectorAll('[data-action="delete"]').forEach((btn) =>
      btn.addEventListener('click', () => {
        if (confirm('Delete this task?')) {
          TaskService.remove(btn.dataset.id);
          refresh();
          Notifications.show('Task deleted', 'success');
        }
      })
    );
  }

  function openForm(existing) {
    const isEdit = !!existing;
    Modal.open({
      title: isEdit ? 'Edit Task' : 'Add Task',
      submitLabel: isEdit ? 'Save Changes' : 'Add Task',
      bodyHtml: `
        <div class="form-group">
          <label>Title</label>
          <input type="text" name="title" class="input" value="${existing?.title ?? ''}" required />
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea name="description" class="input" rows="3">${existing?.description ?? ''}</textarea>
        </div>
        <div class="form-group">
          <label>Category</label>
          <input type="text" name="category" class="input" value="${existing?.category ?? 'General'}" />
        </div>
        <div class="form-group">
          <label>Deadline</label>
          <input type="date" name="deadline" class="input" value="${existing?.deadline ?? ''}" />
        </div>
        <div class="form-group">
          <label>Priority</label>
          <select name="priority" class="input select">
            <option value="low" ${existing?.priority === 'low' ? 'selected' : ''}>Low</option>
            <option value="medium" ${!existing || existing?.priority === 'medium' ? 'selected' : ''}>Medium</option>
            <option value="high" ${existing?.priority === 'high' ? 'selected' : ''}>High</option>
          </select>
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status" class="input select">
            <option value="todo" ${!existing || existing?.status === 'todo' ? 'selected' : ''}>To Do</option>
            <option value="in_progress" ${existing?.status === 'in_progress' ? 'selected' : ''}>In Progress</option>
            <option value="completed" ${existing?.status === 'completed' ? 'selected' : ''}>Completed</option>
          </select>
        </div>
      `,
      onSubmit: (data, close) => {
        const { valid, errors } = Validators.validate(data, {
          title: [[Validators.required, 'Title is required']],
        });
        if (!valid) {
          Notifications.show(Object.values(errors)[0], 'error');
          return;
        }
        if (isEdit) {
          TaskService.edit(existing.id, data);
          Notifications.show('Task updated', 'success');
        } else {
          TaskService.add(data);
          Notifications.show('Task added', 'success');
        }
        close();
        refresh();
      },
    });
  }

  return { render, refresh };
})();
