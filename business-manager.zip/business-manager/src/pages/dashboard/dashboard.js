/**
 * dashboard.js — контроллер главной страницы
 */

const DashboardPage = (() => {
  async function render(container) {
    const html = await fetch('src/pages/dashboard/dashboard.html').then((r) => r.text());
    container.innerHTML = html;
    refresh();
  }

  function refresh() {
    renderStats();
    renderChart();
    renderRecentTransactions();
    renderRecentNotes();
  }

  function renderStats() {
    const finance = FinanceService.summary();
    const customers = CustomerService.count();
    const tasks = TaskService.counts();

    const el = document.getElementById('dashboardStats');
    if (!el) return;
    el.innerHTML = Cards.renderGrid([
      { label: 'Total Revenue', value: Formatters.currency(finance.income), icon: '💵', accent: 'green' },
      { label: 'Total Expenses', value: Formatters.currency(finance.expense), icon: '💸', accent: 'red' },
      { label: 'Net Profit', value: Formatters.currency(finance.profit), icon: '📈', accent: finance.profit >= 0 ? 'green' : 'red' },
      { label: 'Customers', value: Formatters.number(customers), icon: '👥', accent: 'blue' },
      { label: 'Open Tasks', value: Formatters.number(tasks.todo + tasks.in_progress), icon: '✅', accent: 'purple' },
    ]);
  }

  function renderChart() {
    const byMonth = Calculations.groupByMonth(FinanceService.getAll());
    const months = Object.keys(byMonth).sort();
    const labels = months.map((m) => {
      const [y, mo] = m.split('-');
      return new Date(Number(y), Number(mo) - 1, 1).toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
    });

    Charts.lineChart('performanceChart', {
      labels: labels.length ? labels : ['No data'],
      datasets: [
        {
          label: 'Income',
          data: months.length ? months.map((m) => byMonth[m].income) : [0],
          borderColor: '#22c55e',
          backgroundColor: 'rgba(34,197,94,0.12)',
        },
        {
          label: 'Expense',
          data: months.length ? months.map((m) => byMonth[m].expense) : [0],
          borderColor: '#ef4444',
          backgroundColor: 'rgba(239,68,68,0.12)',
        },
      ],
    });
  }

  function renderRecentTransactions() {
    const el = document.getElementById('dashboardRecentTransactions');
    if (!el) return;
    const rows = FinanceService.recent(5);
    const body = Tables.render({
      columns: [
        { key: 'date', label: 'Date', render: (r) => Formatters.date(r.date) },
        { key: 'description', label: 'Description', render: (r) => Formatters.truncate(r.description, 28) || r.category },
        {
          key: 'amount',
          label: 'Amount',
          render: (r) => `<span class="${r.type === 'income' ? 'text-green' : 'text-red'}">${r.type === 'income' ? '+' : '-'}${Formatters.currency(r.amount)}</span>`,
        },
      ],
      rows,
      emptyMessage: 'No transactions yet — add one in Finance',
    });
    el.innerHTML = Cards.simpleCard({ title: 'Recent Transactions', bodyHtml: body });
  }

  function renderRecentNotes() {
    const el = document.getElementById('dashboardRecentNotes');
    if (!el) return;
    const notes = NotesService.recent(4);
    const body = notes.length
      ? `<ul class="mini-list">${notes
          .map((n) => `<li><strong>${n.title}</strong><span>${Formatters.truncate(n.content, 50)}</span></li>`)
          .join('')}</ul>`
      : `<div class="table-empty">No notes yet — add one in Notes</div>`;
    el.innerHTML = Cards.simpleCard({ title: 'Recent Notes', bodyHtml: body });
  }

  return { render, refresh };
})();
