/**
 * customers.js — контроллер раздела Customers (мини-CRM)
 */

const CustomersPage = (() => {
  let state = { search: '', status: 'all' };

  async function render(container) {
    const html = await fetch('src/pages/customers/customers.html').then((r) => r.text());
    container.innerHTML = html;
    state = { search: '', status: 'all' };
    bindEvents();
    refresh();
  }

  function bindEvents() {
    document.getElementById('addCustomerBtn').addEventListener('click', () => openForm());
    document.getElementById('customerSearch').addEventListener('input', (e) => {
      state.search = e.target.value;
      renderTable();
    });
    document.getElementById('customerStatusFilter').addEventListener('change', (e) => {
      state.status = e.target.value;
      renderTable();
    });
  }

  function refresh() {
    renderStats();
    renderTable();
  }

  function renderStats() {
    const all = CustomerService.getAll();
    const active = all.filter((c) => c.status === 'active').length;
    const leads = all.filter((c) => c.status === 'lead').length;
    document.getElementById('customerStats').innerHTML = Cards.renderGrid([
      { label: 'Total Customers', value: Formatters.number(all.length), icon: '👥', accent: 'blue' },
      { label: 'Active', value: Formatters.number(active), icon: '✅', accent: 'green' },
      { label: 'Leads', value: Formatters.number(leads), icon: '🌱', accent: 'purple' },
    ]);
  }

  function getFilteredRows() {
    let rows = state.status !== 'all' ? CustomerService.filterByStatus(state.status) : CustomerService.getAll();
    if (state.search) {
      const q = state.search.toLowerCase();
      rows = rows.filter((c) => c.name.toLowerCase().includes(q) || c.company.toLowerCase().includes(q) || c.contact.toLowerCase().includes(q));
    }
    return rows;
  }

  function renderTable() {
    const rows = getFilteredRows();
    const html = Tables.render({
      columns: [
        { key: 'name', label: 'Name', render: (r) => `<strong>${r.name}</strong>` },
        { key: 'company', label: 'Company', render: (r) => r.company || '—' },
        { key: 'contact', label: 'Contact', render: (r) => r.contact || '—' },
        { key: 'status', label: 'Status', render: (r) => `<span class="badge badge-status-${r.status}">${Formatters.capitalize(r.status)}</span>` },
        { key: 'createdAt', label: 'Added', render: (r) => Formatters.date(r.createdAt) },
      ],
      rows,
      actions: [
        { label: 'Edit', event: 'edit', className: 'btn-ghost' },
        { label: 'Delete', event: 'delete', className: 'btn-danger-ghost' },
      ],
      emptyMessage: 'No customers match your filters',
    });
    const wrapper = document.getElementById('customerTableWrapper');
    wrapper.innerHTML = html;
    wrapper.querySelectorAll('[data-action="edit"]').forEach((btn) =>
      btn.addEventListener('click', () => openForm(Storage.getById(CustomerService.COLLECTION, btn.dataset.id)))
    );
    wrapper.querySelectorAll('[data-action="delete"]').forEach((btn) =>
      btn.addEventListener('click', () => {
        if (confirm('Delete this customer?')) {
          CustomerService.remove(btn.dataset.id);
          refresh();
          Notifications.show('Customer deleted', 'success');
        }
      })
    );
  }

  function openForm(existing) {
    const isEdit = !!existing;
    Modal.open({
      title: isEdit ? 'Edit Customer' : 'Add Customer',
      submitLabel: isEdit ? 'Save Changes' : 'Add Customer',
      bodyHtml: `
        <div class="form-group">
          <label>Name</label>
          <input type="text" name="name" class="input" value="${existing?.name ?? ''}" required />
        </div>
        <div class="form-group">
          <label>Contact (email or phone)</label>
          <input type="text" name="contact" class="input" value="${existing?.contact ?? ''}" />
        </div>
        <div class="form-group">
          <label>Company</label>
          <input type="text" name="company" class="input" value="${existing?.company ?? ''}" />
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status" class="input select">
            <option value="lead" ${!existing || existing?.status === 'lead' ? 'selected' : ''}>Lead</option>
            <option value="active" ${existing?.status === 'active' ? 'selected' : ''}>Active</option>
            <option value="inactive" ${existing?.status === 'inactive' ? 'selected' : ''}>Inactive</option>
          </select>
        </div>
        <div class="form-group">
          <label>Notes</label>
          <textarea name="notes" class="input" rows="3">${existing?.notes ?? ''}</textarea>
        </div>
      `,
      onSubmit: (data, close) => {
        const { valid, errors } = Validators.validate(data, {
          name: [[Validators.required, 'Name is required']],
        });
        if (!valid) {
          Notifications.show(Object.values(errors)[0], 'error');
          return;
        }
        if (isEdit) {
          CustomerService.edit(existing.id, data);
          Notifications.show('Customer updated', 'success');
        } else {
          CustomerService.add(data);
          Notifications.show('Customer added', 'success');
        }
        close();
        refresh();
      },
    });
  }

  return { render, refresh };
})();
