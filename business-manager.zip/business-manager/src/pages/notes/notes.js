/**
 * notes.js — контроллер раздела Notes
 */

const NotesPage = (() => {
  let state = { search: '', category: 'all' };

  async function render(container) {
    const html = await fetch('src/pages/notes/notes.html').then((r) => r.text());
    container.innerHTML = html;
    state = { search: '', category: 'all' };
    bindEvents();
    refresh();
  }

  function bindEvents() {
    document.getElementById('addNoteBtn').addEventListener('click', () => openForm());
    document.getElementById('notesSearch').addEventListener('input', (e) => {
      state.search = e.target.value;
      renderGrid();
    });
    document.getElementById('notesCategoryFilter').addEventListener('change', (e) => {
      state.category = e.target.value;
      renderGrid();
    });
  }

  function refresh() {
    populateCategories();
    renderGrid();
  }

  function populateCategories() {
    const select = document.getElementById('notesCategoryFilter');
    const current = select.value;
    const cats = NotesService.categories();
    select.innerHTML = '<option value="all">All categories</option>' + cats.map((c) => `<option value="${c}">${c}</option>`).join('');
    select.value = cats.includes(current) ? current : 'all';
  }

  function getFilteredNotes() {
    let notes = state.category !== 'all' ? NotesService.filterByCategory(state.category) : NotesService.getAll();
    if (state.search) {
      const q = state.search.toLowerCase();
      notes = notes.filter(
        (n) => n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q) || (n.tags || []).some((t) => t.toLowerCase().includes(q))
      );
    }
    return notes;
  }

  function renderGrid() {
    const notes = getFilteredNotes();
    const grid = document.getElementById('notesGrid');
    if (!notes.length) {
      grid.innerHTML = `<div class="table-empty">No notes found</div>`;
      return;
    }
    grid.innerHTML = notes
      .map(
        (n) => `
      <div class="note-card ${n.pinned ? 'pinned' : ''}">
        <div class="note-card-header">
          <h4>${n.title}</h4>
          <button class="pin-btn" data-action="pin" data-id="${n.id}" title="Pin note">${n.pinned ? '📌' : '📍'}</button>
        </div>
        <p class="note-content">${Formatters.truncate(n.content, 140)}</p>
        <div class="note-tags">
          ${(n.tags || []).map((t) => `<span class="tag">${t}</span>`).join('')}
          <span class="tag tag-category">${n.category}</span>
        </div>
        <div class="note-meta">
          <span>Created ${Formatters.date(n.createdAt)}</span>
          ${n.updatedAt ? `<span>· Edited ${Formatters.date(n.updatedAt)}</span>` : ''}
        </div>
        <div class="note-actions">
          <button class="btn-ghost" data-action="edit" data-id="${n.id}">Edit</button>
          <button class="btn-danger-ghost" data-action="delete" data-id="${n.id}">Delete</button>
        </div>
      </div>
    `
      )
      .join('');

    grid.querySelectorAll('[data-action="pin"]').forEach((btn) =>
      btn.addEventListener('click', () => {
        NotesService.togglePin(btn.dataset.id);
        refresh();
      })
    );
    grid.querySelectorAll('[data-action="edit"]').forEach((btn) =>
      btn.addEventListener('click', () => openForm(Storage.getById(NotesService.COLLECTION, btn.dataset.id)))
    );
    grid.querySelectorAll('[data-action="delete"]').forEach((btn) =>
      btn.addEventListener('click', () => {
        if (confirm('Delete this note?')) {
          NotesService.remove(btn.dataset.id);
          refresh();
          Notifications.show('Note deleted', 'success');
        }
      })
    );
  }

  function openForm(existing) {
    const isEdit = !!existing;
    Modal.open({
      title: isEdit ? 'Edit Note' : 'New Note',
      submitLabel: isEdit ? 'Save Changes' : 'Create Note',
      bodyHtml: `
        <div class="form-group">
          <label>Title</label>
          <input type="text" name="title" class="input" value="${existing?.title ?? ''}" required />
        </div>
        <div class="form-group">
          <label>Content</label>
          <textarea name="content" class="input" rows="5">${existing?.content ?? ''}</textarea>
        </div>
        <div class="form-group">
          <label>Category</label>
          <input type="text" name="category" class="input" value="${existing?.category ?? 'General'}" />
        </div>
        <div class="form-group">
          <label>Tags (comma separated)</label>
          <input type="text" name="tagsRaw" class="input" value="${(existing?.tags || []).join(', ')}" placeholder="marketing, idea, urgent" />
        </div>
      `,
      onSubmit: (data, close) => {
        const { valid, errors } = Validators.validate(data, {
          title: [[Validators.required, 'Title is required']],
        });
        if (!valid) {
          Notifications.show(Object.values(errors)[0], 'error');
          return;
        }
        const tags = (data.tagsRaw || '')
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean);
        const payload = { title: data.title, content: data.content, category: data.category || 'General', tags };
        if (isEdit) {
          NotesService.edit(existing.id, payload);
          Notifications.show('Note updated', 'success');
        } else {
          NotesService.add(payload);
          Notifications.show('Note created', 'success');
        }
        close();
        refresh();
      },
    });
  }

  return { render, refresh };
})();
