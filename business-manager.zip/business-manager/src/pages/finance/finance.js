/**
 * finance.js — контроллер раздела Finance (CRUD доходов/расходов)
 */

const FinancePage = (() => {
  let state = { search: '', type: 'all', category: 'all' };

  async function render(container) {
    const html = await fetch('src/pages/finance/finance.html').then((r) => r.text());
    container.innerHTML = html;
    state = { search: '', type: 'all', category: 'all' };
    bindEvents();
    refresh();
  }

  function bindEvents() {
    document.getElementById('addTransactionBtn').addEventListener('click', () => openForm());

    document.getElementById('financeSearch').addEventListener('input', (e) => {
      state.search = e.target.value;
      refreshTable();
    });
    document.getElementById('financeTypeFilter').addEventListener('change', (e) => {
      state.type = e.target.value;
      refreshTable();
    });
    document.getElementById('financeCategoryFilter').addEventListener('change', (e) => {
      state.category = e.target.value;
      refreshTable();
    });
  }

  function refresh() {
    renderStats();
    populateCategoryFilter();
    refreshTable();
    renderCategoryChart();
  }

  function renderStats() {
    const s = FinanceService.summary();
    document.getElementById('financeStats').innerHTML = Cards.renderGrid([
      { label: 'Total Income', value: Formatters.currency(s.income), icon: '💵', accent: 'green' },
      { label: 'Total Expenses', value: Formatters.currency(s.expense), icon: '💸', accent: 'red' },
      { label: 'Balance', value: Formatters.currency(s.balance), icon: '⚖️', accent: s.balance >= 0 ? 'green' : 'red' },
      { label: 'Transactions', value: Formatters.number(s.count), icon: '🧾', accent: 'blue' },
    ]);
  }

  function populateCategoryFilter() {
    const select = document.getElementById('financeCategoryFilter');
    const current = select.value;
    const cats = FinanceService.categories();
    select.innerHTML =
      '<option value="all">All categories</option>' + cats.map((c) => `<option value="${c}">${c}</option>`).join('');
    select.value = cats.includes(current) ? current : 'all';
  }

  function getFilteredRows() {
    let rows = FinanceService.filter({ type: state.type, category: state.category });
    if (state.search) {
      const q = state.search.toLowerCase();
      rows = rows.filter((t) => t.description.toLowerCase().includes(q) || t.category.toLowerCase().includes(q));
    }
    return rows;
  }

  function refreshTable() {
    const rows = getFilteredRows();
    const html = Tables.render({
      columns: [
        { key: 'date', label: 'Date', render: (r) => Formatters.date(r.date) },
        { key: 'type', label: 'Type', render: (r) => `<span class="badge badge-${r.type}">${Formatters.capitalize(r.type)}</span>` },
        { key: 'category', label: 'Category' },
        { key: 'description', label: 'Description', render: (r) => Formatters.truncate(r.description, 40) },
        {
          key: 'amount',
          label: 'Amount',
          render: (r) => `<span class="${r.type === 'income' ? 'text-green' : 'text-red'}">${r.type === 'income' ? '+' : '-'}${Formatters.currency(r.amount)}</span>`,
        },
      ],
      rows,
      actions: [
        { label: 'Edit', event: 'edit', className: 'btn-ghost' },
        { label: 'Delete', event: 'delete', className: 'btn-danger-ghost' },
      ],
      emptyMessage: 'No transactions match your filters',
    });
    const wrapper = document.getElementById('financeTableWrapper');
    wrapper.innerHTML = html;
    wrapper.querySelectorAll('[data-action="edit"]').forEach((btn) =>
      btn.addEventListener('click', () => openForm(Storage.getById(FinanceService.COLLECTION, btn.dataset.id)))
    );
    wrapper.querySelectorAll('[data-action="delete"]').forEach((btn) =>
      btn.addEventListener('click', () => {
        if (confirm('Delete this transaction?')) {
          FinanceService.remove(btn.dataset.id);
          refresh();
          Notifications.show('Transaction deleted', 'success');
        }
      })
    );
  }

  function renderCategoryChart() {
    const grouped = Calculations.groupByCategory(FinanceService.getAll());
    const labels = Object.keys(grouped);
    const palette = ['#4f46e5', '#22c55e', '#ef4444', '#f59e0b', '#06b6d4', '#a855f7', '#ec4899', '#84cc16'];
    Charts.doughnutChart('financeCategoryChart', {
      labels: labels.length ? labels : ['No data'],
      data: labels.length ? labels.map((l) => grouped[l]) : [1],
      colors: labels.length ? labels.map((_, i) => palette[i % palette.length]) : ['#e5e7eb'],
    });
  }

  function openForm(existing) {
    const isEdit = !!existing;
    Modal.open({
      title: isEdit ? 'Edit Transaction' : 'Add Transaction',
      submitLabel: isEdit ? 'Save Changes' : 'Add Transaction',
      bodyHtml: `
        <div class="form-group">
          <label>Type</label>
          <select name="type" class="input select" required>
            <option value="income" ${existing?.type === 'income' ? 'selected' : ''}>Income</option>
            <option value="expense" ${existing?.type === 'expense' ? 'selected' : ''}>Expense</option>
          </select>
        </div>
        <div class="form-group">
          <label>Amount</label>
          <input type="number" step="0.01" name="amount" class="input" value="${existing?.amount ?? ''}" required />
        </div>
        <div class="form-group">
          <label>Category</label>
          <input type="text" name="category" class="input" value="${existing?.category ?? ''}" placeholder="e.g. Sales, Rent, Marketing" required />
        </div>
        <div class="form-group">
          <label>Date</label>
          <input type="date" name="date" class="input" value="${existing?.date ?? new Date().toISOString().slice(0, 10)}" required />
        </div>
        <div class="form-group">
          <label>Description</label>
          <textarea name="description" class="input" rows="3">${existing?.description ?? ''}</textarea>
        </div>
      `,
      onSubmit: (data, close) => {
        const { valid, errors } = Validators.validate(data, {
          amount: [[Validators.isPositive, 'Amount must be a positive number']],
          category: [[Validators.required, 'Category is required']],
          date: [[Validators.isDate, 'Valid date is required']],
        });
        if (!valid) {
          Notifications.show(Object.values(errors)[0], 'error');
          return;
        }
        if (isEdit) {
          FinanceService.edit(existing.id, data);
          Notifications.show('Transaction updated', 'success');
        } else {
          FinanceService.add(data);
          Notifications.show('Transaction added', 'success');
        }
        close();
        refresh();
      },
    });
  }

  return { render, refresh };
})();
