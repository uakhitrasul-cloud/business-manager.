/**
 * reports.js — контроллер раздела Reports
 */

const ReportsPage = (() => {
  async function render(container) {
    const html = await fetch('src/pages/reports/reports.html').then((r) => r.text());
    container.innerHTML = html;
    bindEvents();
    applyPreset('this_month');
    renderHistory();
  }

  function bindEvents() {
    document.getElementById('reportPreset').addEventListener('change', (e) => applyPreset(e.target.value));
    document.getElementById('generateReportBtn').addEventListener('click', generate);
  }

  function applyPreset(preset) {
    const startInput = document.getElementById('reportStart');
    const endInput = document.getElementById('reportEnd');
    if (preset === 'custom') return;
    const { start, end } = ReportService.presetRange(preset);
    startInput.value = start;
    endInput.value = end;
  }

  function generate() {
    const start = document.getElementById('reportStart').value;
    const end = document.getElementById('reportEnd').value;
    if (!start || !end) {
      Notifications.show('Please select a valid date range', 'error');
      return;
    }
    const presetSelect = document.getElementById('reportPreset');
    const label = `${presetSelect.options[presetSelect.selectedIndex].text} (${Formatters.date(start)} – ${Formatters.date(end)})`;
    const report = ReportService.generate({ start, end, label });
    renderReport(report);
    renderHistory();
    Notifications.show('Report generated', 'success');
  }

  function renderReport(report) {
    const el = document.getElementById('reportResult');
    el.innerHTML = `
      <div class="panel-card">
        <div class="panel-card-header"><h3>${report.label}</h3></div>
        <div class="panel-card-body">
          ${Cards.renderGrid([
            { label: 'Revenue', value: Formatters.currency(report.revenue), icon: '💵', accent: 'green' },
            { label: 'Expenses', value: Formatters.currency(report.expenses), icon: '💸', accent: 'red' },
            { label: 'Profit', value: Formatters.currency(report.profit), icon: '📈', accent: report.profit >= 0 ? 'green' : 'red' },
            { label: 'Transactions', value: Formatters.number(report.transactionCount), icon: '🧾', accent: 'blue' },
          ])}
          <p class="report-line"><strong>Best-performing category:</strong> ${report.bestCategory}</p>
          <div class="chart-container"><canvas id="reportChart"></canvas></div>
        </div>
      </div>
    `;
    const cats = Object.keys(report.byCategory);
    const palette = ['#4f46e5', '#22c55e', '#ef4444', '#f59e0b', '#06b6d4', '#a855f7', '#ec4899', '#84cc16'];
    Charts.barChart('reportChart', {
      labels: cats.length ? cats : ['No data'],
      datasets: [
        {
          label: 'Amount',
          data: cats.length ? cats.map((c) => report.byCategory[c]) : [0],
          backgroundColor: cats.length ? cats.map((_, i) => palette[i % palette.length]) : ['#e5e7eb'],
        },
      ],
    });
  }

  function renderHistory() {
    const history = ReportService.history();
    const html = Tables.render({
      columns: [
        { key: 'label', label: 'Report' },
        { key: 'revenue', label: 'Revenue', render: (r) => Formatters.currency(r.revenue) },
        { key: 'expenses', label: 'Expenses', render: (r) => Formatters.currency(r.expenses) },
        { key: 'profit', label: 'Profit', render: (r) => Formatters.currency(r.profit) },
        { key: 'createdAt', label: 'Generated', render: (r) => Formatters.dateTime(r.createdAt) },
      ],
      rows: history,
      actions: [{ label: 'Delete', event: 'delete', className: 'btn-danger-ghost' }],
      emptyMessage: 'No reports generated yet',
    });
    const el = document.getElementById('reportHistory');
    el.innerHTML = html;
    el.querySelectorAll('[data-action="delete"]').forEach((btn) =>
      btn.addEventListener('click', () => {
        ReportService.remove(btn.dataset.id);
        renderHistory();
        Notifications.show('Report removed', 'success');
      })
    );
  }

  return { render };
})();
